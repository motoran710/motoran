package com.motoran.app

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val blue=Color.rgb(7,93,165); private val gold=Color.rgb(246,189,34)
    override fun onCreate(b: Bundle?) { super.onCreate(b); showHome() }

    private fun tv(t:String, size:Float=16f, bold:Boolean=false): TextView {
        val v=TextView(this); v.text=t; v.textSize=size; v.setTextColor(Color.rgb(23,32,51))
        if(bold) v.setTypeface(null,1); v.setPadding(20,18,20,18); return v
    }
    private fun btn(t:String, action:()->Unit): Button {
        val b=Button(this); b.text=t; b.setOnClickListener{action()}; return b
    }
    private fun showHome() {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(18,18,18,18)
        val head=tv("🚘  موتوران\nخرید و فروش خودرو",27f,true); head.setTextColor(Color.WHITE); head.setBackgroundColor(Color.rgb(6,29,57))
        root.addView(head)
        val search=EditText(this); search.hint="جستجوی برند، مدل یا شهر"; root.addView(search)
        root.addView(btn("ثبت آگهی خودرو",::showAdForm))
        list=LinearLayout(this); list.orientation=LinearLayout.VERTICAL
        root.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); renderCars()
    }
    private fun renderCars() {
        list.removeAllViews()
        val cars=listOf(
            arrayOf("پژو 207 اتومات","1402","980,000,000","تهران","09130000000"),
            arrayOf("هیوندای النترا","1398","1,750,000,000","مشهد","09131111111"),
            arrayOf("تویوتا کرولا","1401","2,450,000,000","اصفهان","09132222222")
        )
        cars.forEach { c ->
            val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(8,12,8,12)
            box.addView(tv(c[0],19f,true)); box.addView(tv("${c[1]} • ${c[3]} • ${c[2]} تومان",14f))
            box.addView(btn("تماس با فروشنده"){ startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c[4]}"))) })
            list.addView(box)
        }
    }
    private fun showAdForm() {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(20,20,20,20)
        root.addView(tv("ثبت آگهی جدید",24f,true))
        val name=EditText(this); name.hint="برند و مدل خودرو"; root.addView(name)
        val year=EditText(this); year.hint="سال ساخت"; root.addView(year)
        val city=EditText(this); city.hint="شهر"; root.addView(city)
        val price=EditText(this); price.hint="قیمت خودرو (تومان)"; root.addView(price)
        val phone=EditText(this); phone.hint="شماره تماس"; root.addView(phone)
        val plans=Spinner(this); plans.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,
            arrayOf("عادی - 50,000 تومان","ویژه - 100,000 تومان","طلایی - 200,000 تومان")); root.addView(plans)
        root.addView(btn("ادامه به پرداخت"){ 
            if(name.text.isBlank()||phone.text.isBlank()) Toast.makeText(this,"نام خودرو و شماره تماس را وارد کنید",Toast.LENGTH_LONG).show()
            else Toast.makeText(this,"سفارش ایجاد شد؛ برای اتصال پرداخت واقعی باید درگاه و سرور تنظیم شود.",Toast.LENGTH_LONG).show()
        })
        root.addView(btn("بازگشت",::showHome)); setContentView(ScrollView(this).apply{addView(root)})
    }
}